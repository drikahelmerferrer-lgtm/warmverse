
import React, { useState, useEffect, useCallback } from 'react';
import { OrderStatus, SongOrder, User } from './types';
import { Player } from './components/Player';

const App: React.FC = () => {
  const [view, setView] = useState<'login' | 'home' | 'form' | 'status' | 'chat' | 'admin'>('login');
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<SongOrder[]>([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedOrderForChat, setSelectedOrderForChat] = useState<SongOrder | null>(null);
  
  const [formData, setFormData] = useState({
    theme: '',
    occasion: '',
    style: '',
    names: '',
    feelings: ''
  });

  useEffect(() => {
    const savedUser = localStorage.getItem('warmverse_user');
    const savedIsAdmin = localStorage.getItem('warmverse_isAdmin') === 'true';
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setIsAdmin(savedIsAdmin);
      setView(savedIsAdmin ? 'admin' : 'home');
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const target = e.target as any;
    const name = target.name.value;
    const whatsapp = target.whatsapp.value;
    
    const ADMIN_SECRET_CODE = 'Marcelaversewarm';
    const isLoggingAsAdmin = name === ADMIN_SECRET_CODE;
    
    const userData = { 
      name: isLoggingAsAdmin ? 'Marcela (Admin)' : name, 
      whatsapp 
    };
    
    setUser(userData);
    setIsAdmin(isLoggingAsAdmin);
    
    localStorage.setItem('warmverse_user', JSON.stringify(userData));
    localStorage.setItem('warmverse_isAdmin', String(isLoggingAsAdmin));
    
    setView(isLoggingAsAdmin ? 'admin' : 'home');
  };

  const handleLogout = () => {
    localStorage.clear();
    setUser(null);
    setIsAdmin(false);
    setView('login');
  };

  const submitOrder = useCallback((finalData: typeof formData) => {
    const newOrder: SongOrder = {
      id: Math.random().toString(36).substr(2, 9),
      ...finalData,
      status: OrderStatus.IN_PROGRESS,
      createdAt: new Date().toLocaleDateString('pt-BR'),
      audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
    };
    setOrders(prev => [newOrder, ...prev]);
    setView('status');
  }, []);

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
  };

  const openCustomerWhatsApp = (customerWhatsapp: string, theme: string) => {
    const cleanNumber = customerWhatsapp.replace(/\D/g, '');
    const message = encodeURIComponent(`Olá! Aqui é a Marcela do Warmverse. Vamos falar sobre sua música "${theme}"?`);
    window.open(`https://wa.me/55${cleanNumber}?text=${message}`, '_blank');
  };

  const RenderLogin = () => (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gray-50">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-warmverse mb-2 tracking-tight">Warmverse</h1>
        <p className="text-gray-500 text-sm">Transformando Histórias em Música</p>
      </div>
      <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4">
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-400 uppercase ml-2">Seu Nome</label>
          <input required name="name" type="text" placeholder="Como podemos te chamar?" className="w-full p-4 rounded-2xl border-none shadow-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-400 uppercase ml-2">WhatsApp</label>
          <input required name="whatsapp" type="tel" placeholder="(00) 00000-0000" className="w-full p-4 rounded-2xl border-none shadow-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
        </div>
        <button type="submit" className="w-full py-4 gradient-bg text-white rounded-2xl font-bold text-lg shadow-xl hover:opacity-90 active:scale-95 transition-all">
          Entrar no Warmverse
        </button>
      </form>
    </div>
  );

  const RenderAdminDashboard = () => (
    <div className="min-h-screen bg-gray-50 pb-24">
      <header className="p-6 pt-12 bg-white shadow-sm flex justify-between items-center border-b">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Olá, Marcela! 👑</h2>
          <p className="text-gray-500 text-sm">Painel de Suporte e Gestão</p>
        </div>
        <button onClick={handleLogout} className="text-gray-300 p-2 hover:text-red-500 transition-colors"><i className="fas fa-power-off text-xl"></i></button>
      </header>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-3xl shadow-sm border-l-4 border-blue-600">
            <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">Total</p>
            <p className="text-3xl font-black text-gray-800">{orders.length}</p>
          </div>
          <div className="bg-white p-5 rounded-3xl shadow-sm border-l-4 border-yellow-500">
            <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">Ativos</p>
            <p className="text-3xl font-black text-gray-800">{orders.filter(o => o.status !== OrderStatus.COMPLETED).length}</p>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-gray-400 text-xs uppercase tracking-widest ml-1 text-center">Central de Pedidos</h3>
          {orders.length === 0 ? (
            <div className="p-12 text-center text-gray-400 bg-white rounded-3xl border-2 border-dashed">
              <i className="fas fa-music text-4xl mb-3 opacity-10"></i>
              <p className="text-sm">Aguardando novos pedidos...</p>
            </div>
          ) : (
            orders.map(order => (
              <div key={order.id} className="bg-white p-5 rounded-3xl shadow-sm space-y-4 border border-gray-100">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase ${order.status === OrderStatus.COMPLETED ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'}`}>
                      {order.status}
                    </span>
                    <h4 className="font-bold text-lg mt-2 text-gray-800 leading-tight">{order.theme}</h4>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center text-green-600">
                        <i className="fab fa-whatsapp text-sm"></i>
                      </div>
                      <p className="text-xs font-black text-gray-600">{user?.whatsapp}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => openCustomerWhatsApp(user?.whatsapp || '', order.theme)} 
                    className="w-14 h-14 bg-green-500 text-white rounded-2xl flex items-center justify-center shadow-lg hover:bg-green-600 transition-colors animate-pulse"
                    title="Chamar no WhatsApp"
                  >
                    <i className="fab fa-whatsapp text-2xl"></i>
                  </button>
                </div>
                
                <div className="text-sm bg-gray-50 p-4 rounded-2xl border border-gray-100 cursor-pointer" onClick={() => { setSelectedOrderForChat(order); setView('chat'); }}>
                  <p className="mb-2 text-[10px] text-gray-400 font-bold uppercase">Ver detalhes & Iniciar Chat Interno</p>
                  <p className="mb-1 italic text-gray-600 line-clamp-2">"{order.feelings}"</p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <select 
                    onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                    className="flex-1 bg-gray-100 p-4 rounded-2xl text-xs font-bold outline-none cursor-pointer border-none shadow-inner"
                    value={order.status}
                  >
                    <option value={OrderStatus.IN_PROGRESS}>🟡 Em Produção</option>
                    <option value={OrderStatus.ADJUSTING}>🟠 Em Ajuste</option>
                    <option value={OrderStatus.COMPLETED}>🟢 Finalizada</option>
                  </select>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );

  const RenderHome = () => (
    <div className="min-h-screen bg-white pb-24">
      <header className="p-6 pt-12 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 leading-tight">Olá, {user?.name.split(' ')[0]}! 👋</h2>
          <p className="text-gray-500">Sua trilha sonora começa aqui.</p>
        </div>
        <button onClick={handleLogout} className="text-gray-200 p-2 hover:text-gray-400 transition-colors"><i className="fas fa-sign-out-alt"></i></button>
      </header>

      <section className="px-6 mb-8">
        <div className="gradient-bg rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="text-xl font-bold mb-6">Processo Warmverse</h3>
            <div className="space-y-5">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-bold">1</div>
                <p className="text-sm font-medium opacity-90">Conte sua história em detalhes.</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-bold">2</div>
                <p className="text-sm font-medium opacity-90">Produzimos sua música exclusiva.</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-bold">3</div>
                <p className="text-sm font-medium opacity-90">Ajustamos até ficar perfeito.</p>
              </div>
            </div>
          </div>
          <i className="fas fa-microphone-alt absolute -bottom-6 -right-6 text-white/10 text-[10rem]"></i>
        </div>
      </section>

      <div className="px-6 space-y-4">
        <div className="flex justify-between items-center">
          <h4 className="font-bold text-gray-800 text-lg">Suas Músicas</h4>
          <span className="text-xs font-bold text-blue-500 bg-blue-50 px-3 py-1 rounded-full">{orders.length}</span>
        </div>
        {orders.length === 0 ? (
          <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-[2rem] p-12 text-center">
            <i className="fas fa-music text-3xl text-gray-200 mb-4 block"></i>
            <p className="text-gray-400 text-sm">Nenhuma música encomendada.</p>
          </div>
        ) : (
          orders.map(order => (
            <div key={order.id} onClick={() => { setSelectedOrderForChat(order); setView('status'); }} className="bg-white border border-gray-100 rounded-3xl p-5 flex items-center justify-between shadow-sm cursor-pointer hover:shadow-md transition-all active:scale-98">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-warmverse text-xl">
                  <i className="fas fa-headphones-alt"></i>
                </div>
                <div>
                  <p className="font-bold text-gray-800 leading-tight">{order.theme}</p>
                  <p className="text-[10px] font-bold text-blue-500 mt-1 uppercase tracking-wider">{order.status}</p>
                </div>
              </div>
              <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-300">
                <i className="fas fa-chevron-right text-xs"></i>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white/90 backdrop-blur-xl">
        <button onClick={() => setView('form')} className="w-full py-5 gradient-bg text-white rounded-[1.5rem] font-bold shadow-2xl flex items-center justify-center gap-3 transition-transform active:scale-95">
          <i className="fas fa-plus"></i> Criar Nova Música
        </button>
      </div>
    </div>
  );

  const RenderForm = () => {
    const [localFormData, setLocalFormData] = useState(formData);
    const updateField = (field: string, value: string) => {
      setLocalFormData(prev => ({ ...prev, [field]: value }));
    };

    return (
      <div className="min-h-screen bg-gray-50 p-6 pb-32">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => setView('home')} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-gray-600 hover:bg-gray-50 transition-colors">
            <i className="fas fa-arrow-left"></i>
          </button>
          <h2 className="text-xl font-bold text-gray-800">Criação Musical</h2>
        </div>

        <div className="flex justify-between mb-10 px-2 gap-2">
          {[1, 2, 3].map(s => (
            <div key={s} className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${currentStep >= s ? 'bg-warmverse' : 'bg-gray-200'}`}></div>
          ))}
        </div>

        <div className="bg-white rounded-[2.5rem] p-8 shadow-sm transition-all duration-300">
          {currentStep === 1 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">Sobre o que é a música?</h3>
              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase ml-2">Título ou Tema</label>
                  <input value={localFormData.theme} onChange={e => updateField('theme', e.target.value)} className="w-full p-5 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-blue-400 outline-none text-gray-800" placeholder="Ex: Casamento João e Ana" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase ml-2">Ocasião</label>
                  <select value={localFormData.occasion} onChange={e => updateField('occasion', e.target.value)} className="w-full p-5 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-blue-400 outline-none appearance-none cursor-pointer">
                    <option value="">Selecione...</option>
                    <option value="aniversario">Aniversário</option>
                    <option value="casamento">Casamento</option>
                    <option value="empresa">Empresa / Jingle</option>
                    <option value="igreja">Igreja / Religioso</option>
                    <option value="outro">Outro Presente</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">Estilo e Emoção</h3>
              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase ml-2">Gênero Musical</label>
                  <input value={localFormData.style} onChange={e => updateField('style', e.target.value)} className="w-full p-5 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-blue-400 outline-none" placeholder="Ex: Pop, Sertanejo, Rock..." />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase ml-2">Sentimentos</label>
                  <textarea value={localFormData.feelings} onChange={e => updateField('feelings', e.target.value)} className="w-full p-5 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-blue-400 h-32 outline-none resize-none" placeholder="Ex: Alegria, gratidão, amor eterno..." />
                </div>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-800">Nomes e Detalhes</h3>
              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase ml-2">Nomes Importantes</label>
                  <input value={localFormData.names} onChange={e => updateField('names', e.target.value)} className="w-full p-5 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-blue-400 outline-none" placeholder="Quem deve ser citado na letra?" />
                </div>
                <div className="p-6 bg-blue-50/50 rounded-3xl border border-blue-100 flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-blue-500 shadow-sm">
                    <i className="fas fa-heart"></i>
                  </div>
                  <p className="text-xs text-blue-700 font-medium leading-relaxed">Nossa equipe revisará sua história para garantir uma letra emocionante.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-6 flex gap-4 bg-white/80 backdrop-blur-xl">
          {currentStep > 1 && (
            <button onClick={() => setCurrentStep(prev => prev - 1)} className="flex-1 py-5 bg-gray-100 text-gray-500 rounded-3xl font-bold hover:bg-gray-200 transition-colors">Voltar</button>
          )}
          <button onClick={() => { if (currentStep < 3) { setCurrentStep(prev => prev + 1); setFormData(localFormData); } else { submitOrder(localFormData); } }} className="flex-[2] py-5 gradient-bg text-white rounded-3xl font-bold shadow-2xl transition-all active:scale-95">
            {currentStep === 3 ? 'Finalizar Encomenda' : 'Próximo Passo'}
          </button>
        </div>
      </div>
    );
  };

  const RenderStatus = () => {
    const currentOrder = selectedOrderForChat || orders[0];
    return (
      <div className="min-h-screen bg-gray-50 p-6 pb-32">
        <div className="flex items-center justify-between mb-8">
          <button onClick={() => setView('home')} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-gray-600"><i className="fas fa-arrow-left"></i></button>
          <h2 className="text-xl font-bold text-gray-800">Status da Música</h2>
          <div className="w-12 h-12"></div>
        </div>

        <div className="bg-white rounded-[2.5rem] p-8 shadow-sm mb-6 border border-gray-100">
          <div className="flex items-center gap-5 mb-10">
            <div className="w-20 h-20 bg-blue-50 rounded-[2rem] flex items-center justify-center text-3xl text-warmverse shadow-inner">
              <i className={`fas ${currentOrder?.status === OrderStatus.COMPLETED ? 'fa-check-circle text-green-500' : 'fa-compact-disc fa-spin'}`}></i>
            </div>
            <div>
              <h3 className="font-bold text-xl text-gray-800">{currentOrder?.theme}</h3>
              <span className="text-blue-500 text-xs font-black uppercase tracking-widest">{currentOrder?.status}</span>
            </div>
          </div>

          <div className="space-y-10 relative before:content-[''] before:absolute before:left-[15px] before:top-2 before:bottom-2 before:w-[2px] before:bg-gray-100">
            <div className="flex items-center gap-6 relative">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-[10px] z-10 shadow-lg shadow-green-100"><i className="fas fa-check"></i></div>
              <p className="font-bold text-gray-800 text-sm">Pedido Recebido</p>
            </div>
            <div className="flex items-center gap-6 relative">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] z-10 ${currentOrder?.status !== OrderStatus.PENDING ? 'bg-blue-500 shadow-lg shadow-blue-100' : 'bg-gray-100'}`}>
                <i className={`fas ${currentOrder?.status === OrderStatus.IN_PROGRESS ? 'fa-spinner fa-spin' : 'fa-music'}`}></i>
              </div>
              <p className={`font-bold text-sm ${currentOrder?.status !== OrderStatus.PENDING ? 'text-gray-800' : 'text-gray-300'}`}>Produção Artística</p>
            </div>
            <div className="flex items-center gap-6 relative">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] z-10 ${currentOrder?.status === OrderStatus.COMPLETED ? 'bg-green-500 shadow-lg shadow-green-100' : 'bg-gray-100'}`}>
                <i className="fas fa-star"></i>
              </div>
              <p className={`font-bold text-sm ${currentOrder?.status === OrderStatus.COMPLETED ? 'text-gray-800' : 'text-gray-300'}`}>Entrega Final</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => setView('chat')} className="py-5 bg-green-500 text-white rounded-3xl font-bold text-xs flex items-center justify-center gap-2 shadow-xl shadow-green-100 active:scale-95 transition-all">
            <i className="fab fa-whatsapp text-lg"></i> Suporte Direto
          </button>
          <button className="py-5 bg-white border border-gray-100 text-gray-400 rounded-3xl font-bold text-xs shadow-sm active:scale-95 transition-all">Solicitar Ajustes</button>
        </div>

        <div className="mt-8 p-8 bg-blue-50/50 rounded-[2.5rem] border border-blue-100 text-center">
          <h4 className="font-black text-blue-900 mb-2 uppercase tracking-tighter text-lg">Produção Profissional</h4>
          <p className="text-xs text-blue-600/70 mb-6 px-4">Após o pagamento do Pix, iniciamos a gravação definitiva com músicos.</p>
          <button className="w-full py-5 gradient-bg text-white rounded-3xl font-bold shadow-2xl active:scale-95 transition-all">Pagar com Pix R$ 149,90</button>
        </div>
      </div>
    );
  };

  const RenderChat = () => (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="p-6 pt-12 bg-white shadow-sm flex items-center gap-4 border-b">
        <button onClick={() => setView(isAdmin ? 'admin' : 'status')} className="w-10 h-10 flex items-center justify-center text-gray-400"><i className="fas fa-arrow-left"></i></button>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-warmverse rounded-2xl flex items-center justify-center text-white shadow-lg">
            <i className={`fas ${isAdmin ? 'fa-headset' : 'fa-user-tie'}`}></i>
          </div>
          <div>
            <h4 className="font-bold text-sm text-gray-800 leading-none">{isAdmin ? 'Suporte Warmverse' : 'Consultor Warmverse'}</h4>
            <span className="text-[10px] text-green-500 flex items-center gap-1 font-bold mt-1">Chat Ativo</span>
          </div>
        </div>
      </header>

      <div className="flex-1 p-6 space-y-6 overflow-y-auto">
        <div className="bg-white p-6 rounded-[2rem] rounded-tl-none shadow-sm max-w-[90%] text-sm text-gray-700 leading-relaxed border border-gray-100">
          {isAdmin ? (
            <div className="space-y-3">
              <p className="text-[10px] font-bold text-blue-500 uppercase">Resumo da Encomenda:</p>
              <div className="p-4 bg-gray-50 rounded-2xl space-y-2 border border-gray-100">
                <p><strong>Status:</strong> {selectedOrderForChat?.status}</p>
                <p><strong>Estilo:</strong> {selectedOrderForChat?.style}</p>
                <p className="text-blue-600 font-bold"><strong>Tema:</strong> {selectedOrderForChat?.theme}</p>
              </div>
              <p className="pt-2">Olá! Marcela aqui. Analisando seu pedido. Como posso te ajudar?</p>
            </div>
          ) : (
            <p>Olá! Recebemos sua história e estamos muito felizes em transformá-la em música. Em que podemos te ajudar hoje?</p>
          )}
        </div>
      </div>

      <div className="p-6 bg-white flex flex-col gap-3 border-t">
        <div className="flex gap-3">
          <textarea 
            className="flex-1 bg-gray-50 rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-blue-100 text-sm resize-none h-24" 
            placeholder={isAdmin ? "Escreva aqui para o chat interno..." : "Escreva sua dúvida aqui..."}
          ></textarea>
        </div>
        <button className="w-full py-4 gradient-bg text-white rounded-2xl font-bold shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2">
          <i className="fas fa-paper-plane"></i> Enviar no Chat
        </button>
        {isAdmin && (
           <button 
             onClick={() => openCustomerWhatsApp(user?.whatsapp || '', selectedOrderForChat?.theme || '')}
             className="w-full py-3 bg-green-500 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2"
           >
             <i className="fab fa-whatsapp"></i> Chamar no WhatsApp agora
           </button>
        )}
      </div>
    </div>
  );

  return (
    <main className="max-w-md mx-auto min-h-screen relative shadow-2xl bg-white overflow-x-hidden">
      {view === 'login' && <RenderLogin />}
      {view === 'admin' && <RenderAdminDashboard />}
      {view === 'home' && <RenderHome />}
      {view === 'form' && <RenderForm />}
      {view === 'status' && <RenderStatus />}
      {view === 'chat' && <RenderChat />}
      
      {view !== 'login' && !isAdmin && (
        <a href="https://wa.me/5519978202025" target="_blank" rel="noopener noreferrer" className="fixed bottom-24 right-6 w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center shadow-2xl z-50 hover:scale-110 transition-transform active:scale-90">
          <i className="fab fa-whatsapp text-3xl"></i>
        </a>
      )}
    </main>
  );
};

export default App;
