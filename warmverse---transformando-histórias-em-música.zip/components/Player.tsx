
import React, { useState, useRef } from 'react';

interface PlayerProps {
  url: string;
  title: string;
}

export const Player: React.FC<PlayerProps> = ({ url, title }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="bg-white border rounded-2xl p-4 shadow-sm flex items-center space-x-4">
      <audio ref={audioRef} src={url} onEnded={() => setIsPlaying(false)} />
      <button 
        onClick={togglePlay}
        className="w-12 h-12 bg-warmverse text-white rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors"
      >
        <i className={`fas ${isPlaying ? 'fa-pause' : 'fa-play'}`}></i>
      </button>
      <div className="flex-1">
        <h4 className="font-semibold text-gray-800 text-sm">{title}</h4>
        <div className="h-1 bg-gray-100 rounded-full mt-2 relative overflow-hidden">
          <div className={`h-full bg-blue-500 transition-all duration-300 ${isPlaying ? 'w-2/3' : 'w-0'}`}></div>
        </div>
      </div>
    </div>
  );
};
